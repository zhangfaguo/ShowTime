﻿using System;
using System.Collections.Generic;
using System.Linq;
using ${Module}.DomainService.Contracts;
using ${Module}.DomainService.Objects;
using ${Module}.Objects.Model;
using ${Module}.BaseServices;

namespace ${Module}.DomainService.Services
{
    public class ${ClassName}Service : ServiceBase<${ClassName}Info, ${ClassName}>, I${ClassName}Service
    {

    }
}
