﻿using System;
using System.Collections.Generic;
using System.Linq;
using ${Module}.DomainService.Objects;
using ${Module}.BaseServices;


namespace ${Module}.DomainService.Contracts
{
    public interface I${ClassName}Service : IServiceBase<${ClassName}Info>
    {
		
    }
}
