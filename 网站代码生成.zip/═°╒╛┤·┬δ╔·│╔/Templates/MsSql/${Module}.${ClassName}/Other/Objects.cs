﻿public class ${ClassName}Model : PageBaseDTO<${ClassName}Condition>
{
#foreach($column in $Table.Columns)
  ///<summary>
  ///$Helper.StringToSingleLine($column.Comments)
  ///</summary>
  public $Helper.SqlToCS($column.DataType) $column.Property
  {
     get{ 
           return Source.$column.Property;
     }
     set{
         Source.$column.Property=value;
     }
  }
#end
}

public class ${ClassName}Condition:PageInfo
{
#foreach($column in $Table.Columns)
  ///<summary>
  ///$Helper.StringToSingleLine($column.Comments)
  ///</summary>
  public $Helper.SqlToCS($column.DataType) $column.Property
  {
    get;set;
  }
#end
}


public IList<${ClassName}Info> Search(${ClassName}Info.${ClassName}Condition condition)
{
    var query =Set;
   #foreach($column in $Table.Columns)
      #if($Helper.SqlToCS($column.DataType)=="string")

        //$Helper.StringToSingleLine($column.Comments)
        if(!string.IsNullOrEmpty(condition.${column.Property}))
        {
          query.Where(c=>c.${column.Property}.Contains(condition.${column.Property}));
          query.Where(c=>c.${column.Property} == condition.${column.Property});
        }

      #else
        #if($Helper.SqlToCS($column.DataType)=="DateTime")

        //$Helper.StringToSingleLine($column.Comments)
        if(condition.${column.Property}>DateTime.MinValue)
        {
          query.Where(c=>c.${column.Property} > condition.${column.Property});
        }

        #else

        //$Helper.StringToSingleLine($column.Comments)
        if(condition.${column.Property} > 0)
        {
          query.Where(c=>c.${column.Property} == condition.${column.Property});
        }

        #end
     #end
  #end
query=query.OrderBy(c=>c.ID);
var list=  Paging(query,condition);
return To<IList<${ClassName}Info>, IList<${ClassName}>>(list.ToList());
}